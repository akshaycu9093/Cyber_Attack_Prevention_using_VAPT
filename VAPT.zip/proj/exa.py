from tkinter import *
import tkinter.messagebox as tm
import subprocess

class LoginFrame(Frame):
    def __init__(self, master):
        super().__init__(master)

        self.label_username = Label(self, text="Username")
        self.label_password = Label(self, text="Password")

        self.entry_username = Entry(self)
        self.entry_password = Entry(self, show="*")

        self.label_username.grid(row=0, sticky=E)
        self.label_password.grid(row=1, sticky=E)
        self.entry_username.grid(row=0, column=1)
        self.entry_password.grid(row=1, column=1)

        self.checkbox = Checkbutton(self, text="Keep me logged in")
        self.checkbox.grid(columnspan=2)

        self.logbtn = Button(self, text="Login", command=self._login_btn_clicked)
        self.logbtn.grid(columnspan=2)
	top = Toplevel()
	self.clsbtn = Button(self, text = "Close", command = top.quit)
	self.clsbtn.grid(columnspan = 2)

        self.pack()

   

    def _login_btn_clicked(self):
        # print("Clicked")
        username = self.entry_username.get()
        password = self.entry_password.get()

        # print(username, password)

        if username == "1234" and password == "1234":
            subprocess.call(["python3", "programlist.py"])
            quit()
        else:
            tm.showerror("Login error", "Incorrect username")

	    


root = Tk()
lf = LoginFrame(root)
root.mainloop()
